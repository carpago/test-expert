package suitetest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({tests.p1.P1Test.class, tests.p2.ConcreteP2Test.class})
public class TestSuite {

}
