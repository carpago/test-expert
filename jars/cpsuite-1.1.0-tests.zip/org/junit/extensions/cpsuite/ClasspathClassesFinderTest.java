package org.junit.extensions.cpsuite;

import java.util.*;

import org.junit.*;

public class ClasspathClassesFinderTest {

	class AcceptAllClassesInTestDirTester extends AcceptAllTester {
		@Override
		public boolean acceptClassName(String className) {
			return className.startsWith("tests.");
		}

		@Override
		public boolean searchInJars() {
			return false;
		}
	}

	@Test
	public void allClasses() {
		ClassTester tester = new AcceptAllClassesInTestDirTester();
		Collection<Class<?>> classes = new ClasspathClassesFinder(tester)
				.find();
		Assert.assertEquals(7, classes.size());
		classes.contains(tests.ju38.JU38AbstractTest.class);
		classes.contains(tests.ju38.JU38Test.class);
		classes.contains(tests.p1.P1Test.class);
		classes.contains(tests.p1.P1NoTest.class);
		classes.contains(tests.p1.P1NoTest.InnerTest.class);
		classes.contains(tests.p2.AbstractP2Test.class);
		classes.contains(tests.p2.ConcreteP2Test.class);
	}

	@Test
	public void allClassNames() {
		final Set<String> allClasses = new HashSet<String>();
		allClasses.add("tests.ju38.JU38AbstractTest");
		allClasses.add("tests.ju38.JU38Test");
		allClasses.add("tests.p1.P1Test");
		allClasses.add("tests.p1.P1NoTest");
		allClasses.add("tests.p1.P1NoTest$InnerTest");
		allClasses.add("tests.p2.AbstractP2Test");
		allClasses.add("tests.p2.ConcreteP2Test");
		ClassTester tester = new AcceptAllClassesInTestDirTester() {
			@Override
			public boolean acceptClassName(String className) {
				if (className.startsWith("tests.")) {
					Assert.assertTrue(allClasses.contains(className));
				}
				return super.acceptClassName(className);
			}
		};
		Collection<Class<?>> classes = new ClasspathClassesFinder(tester)
				.find();
		Assert.assertEquals(allClasses.size(), classes.size());
	}

	@Test
	public void allClassesExceptInner() {
		ClassTester tester = new AcceptAllClassesInTestDirTester() {
			@Override
			public boolean acceptInnerClass() {
				return false;
			}
		};
		Collection<Class<?>> classes = new ClasspathClassesFinder(tester)
				.find();
		Assert.assertEquals(6, classes.size());
	}

	@Test
	public void selectClassByAcceptClass() {
		ClassTester tester = new AcceptAllClassesInTestDirTester() {
			@Override
			public boolean acceptClass(Class<?> clazz) {
				return clazz.getName().endsWith("NoTest");
			}
		};
		Collection<Class<?>> classes = new ClasspathClassesFinder(tester)
				.find();
		Assert.assertEquals(1, classes.size());
	}

	@Test
	public void dontSearchJarsIfSpecified() {
		ClassTester tester = new AcceptAllTester() {
			@Override
			public boolean searchInJars() {
				return false;
			}

			@Override
			public boolean acceptClassName(String className) {
				return className.startsWith("injar.");
			}
		};
		Collection<Class<?>> classes = new ClasspathClassesFinder(tester)
				.find();
		Assert.assertEquals(0, classes.size());
	}

	@Test
	public void allClassesIncludingJarFiles() {
		ClassTester tester = new AcceptAllTester() {
			@Override
			public boolean searchInJars() {
				return true;
			}

			@Override
			public boolean acceptClassName(String className) {
				return className.startsWith("injar.");
			}
		};
		Collection<Class<?>> classes = new ClasspathClassesFinder(tester)
				.find();
		Assert.assertEquals(4, classes.size());
	}
}
