package org.junit.extensions.cpsuite;

import static org.junit.Assert.*;

import java.io.File;
import java.util.Iterator;

import org.junit.Test;

public class JarFilenameIteratorTest {

	@Test
	public void recursiveRoot() throws Exception {
		Iterator<String> i = new JarFilenameIterator(new File(
				"tests/mytests.jar"));
		assertTrue(i.hasNext());
		assertNotNull(i.next()); //Manifest-File
		assertNotNull(i.next());
		assertNotNull(i.next());
		assertNotNull(i.next());
		assertNotNull(i.next());
		assertFalse(i.hasNext());
	}
}
