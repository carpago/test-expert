package org.junit.extensions.cpsuite;

import static org.junit.Assert.*;

import org.junit.*;

public class ClasspathSuiteTesterTest {

	private ClasspathSuiteTester tester;
	private SuiteType[] suiteTypes;

	@Before
	public void initTester() {
		suiteTypes = new SuiteType[] { SuiteType.TEST_CLASSES };
		tester = new ClasspathSuiteTester(true, null, suiteTypes);
	}

	@Test
	public void acceptInnerClasses() {
		assertTrue(tester.acceptInnerClass());
	}

	@Test
	public void dontAcceptNonTestClass() {
		assertFalse(tester.acceptClass(tests.p1.P1NoTest.class));
		assertFalse(tester.acceptClass(suitetest.TestSuite.class));
	}

	@Test
	public void acceptTestClass() {
		assertTrue(tester.acceptClass(tests.p1.P1Test.class));
	}

	@Test
	public void dontAcceptNonRunWithClassWhenSuiteTypeIsRunWith() {
		suiteTypes = new SuiteType[] { SuiteType.RUN_WITH_CLASSES };
		tester = new ClasspathSuiteTester(true, null, suiteTypes);
		assertFalse(tester.acceptClass(tests.p1.P1Test.class));
		assertFalse(tester.acceptClass(tests.p1.P1NoTest.class));
	}

	@Test
	public void acceptRunWithClassesWhenSuiteTypeIsRunWith() {
		suiteTypes = new SuiteType[] { SuiteType.RUN_WITH_CLASSES };
		tester = new ClasspathSuiteTester(true, null, suiteTypes);
		assertTrue(tester.acceptClass(suitetest.TestSuite.class));
	}

	@Test
	public void dontAcceptRunWithClassesThatUseClasspathSuiteThemselves() {
		suiteTypes = new SuiteType[] { SuiteType.RUN_WITH_CLASSES };
		tester = new ClasspathSuiteTester(true, null, suiteTypes);
		assertFalse(tester.acceptClass(suitetest.ACPTestSuite.class));
	}

	@Test
	public void acceptRunWithAndTestClasses() {
		suiteTypes = new SuiteType[] { SuiteType.RUN_WITH_CLASSES,
				SuiteType.TEST_CLASSES };
		tester = new ClasspathSuiteTester(true, null, suiteTypes);
		assertTrue(tester.acceptClass(suitetest.TestSuite.class));
		assertTrue(tester.acceptClass(tests.p1.P1Test.class));
		assertFalse(tester.acceptClass(tests.p1.P1NoTest.class));
	}

	@Test
	public void abstractTestClasses() {
		assertFalse(tester.acceptClass(tests.p2.AbstractP2Test.class));
		assertTrue(tester.acceptClass(tests.p2.ConcreteP2Test.class));
	}

	@Test
	public void dontAcceptJUnit38TestClassByDefault() {
		assertFalse(tester.acceptClass(tests.ju38.JU38Test.class));
	}

	@Test
	public void acceptJUnit38TestClassIfConfigured() {
		suiteTypes = new SuiteType[] { SuiteType.JUNIT38_TEST_CLASSES };
		tester = new ClasspathSuiteTester(false, null, suiteTypes);
		assertTrue(tester.acceptClass(tests.ju38.JU38Test.class));
		assertFalse(tester.acceptClass(tests.ju38.JU38AbstractTest.class));
	}

	@Test
	public void filterPatternsNull() {
		assertTrue(tester.acceptClassName("oops.MyClass"));
		assertTrue(tester.acceptClassName("TopLevel"));
	}

	@Test
	public void oneFilterPattern() {
		String[] patterns = new String[] { "oops.*" };
		tester = new ClasspathSuiteTester(true, patterns, suiteTypes);
		assertTrue(tester.acceptClassName("oops.MyClass"));
		assertFalse(tester.acceptClassName("TopLevel"));
	}

	@Test
	public void twoFilterPattern() {
		String[] patterns = new String[] { "oops.*", ".*Test" };
		tester = new ClasspathSuiteTester(true, patterns, suiteTypes);
		assertTrue(tester.acceptClassName("oops.MyClass"));
		assertFalse(tester.acceptClassName("TopLevel"));
		assertTrue(tester.acceptClassName("ppp.MyTest"));
	}

	@Test
	public void negationFilter() {
		//	Accept all tests except those matching "oops.*"
		String[] patterns = new String[] { "!oops.*" };
		tester = new ClasspathSuiteTester(true, patterns, suiteTypes);
		assertTrue(tester.acceptClassName("TopLevel"));
		assertFalse(tester.acceptClassName("oops.MyTest"));
	}

	@Test
	public void filtersPlusNegationFilters() {
		//	Accept all tests that match any positive filter AND do not match any negation filter
		String[] patterns = new String[] { "oops.*", "!.*Test", ".allo.*",
				"!h.*" };
		tester = new ClasspathSuiteTester(true, patterns, suiteTypes);
		assertFalse(tester.acceptClassName("TopLevel"));
		assertFalse(tester.acceptClassName("oops.MyTest"));
		assertTrue(tester.acceptClassName("oops.MyOops"));
		assertFalse(tester.acceptClassName("hallo.AnOops"));
		assertTrue(tester.acceptClassName("dallo.AnOops"));
	}

	@Test
	public void searchInJars() {
		assertTrue(new ClasspathSuiteTester(true, new String[0], suiteTypes)
				.searchInJars());
		assertFalse(new ClasspathSuiteTester(false, new String[0], suiteTypes)
				.searchInJars());
	}

}
