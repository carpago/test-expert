package samples;

import org.junit.extensions.cpsuite.ClasspathSuite;
import org.junit.extensions.cpsuite.ClasspathSuite.*;
import org.junit.runner.RunWith;

import static org.junit.extensions.cpsuite.SuiteType.*;

@RunWith(ClasspathSuite.class)
@ClassnameFilters({"suitetest.*TestSuite"})
@SuiteTypes(RUN_WITH_CLASSES)
public class AllRunWithSuites {

}
