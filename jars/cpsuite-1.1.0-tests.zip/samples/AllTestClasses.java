package samples;

import static org.junit.extensions.cpsuite.SuiteType.*;
import junit.framework.JUnit4TestAdapter;

import org.junit.extensions.cpsuite.ClasspathSuite;
import org.junit.extensions.cpsuite.ClasspathSuite.*;
import org.junit.runner.RunWith;

@RunWith(ClasspathSuite.class)
@ClassnameFilters( { "injar.*", "tests.*" })
@SuiteTypes( { JUNIT38_TEST_CLASSES, TEST_CLASSES })
@IncludeJars(true)
public class AllTestClasses {

	public static junit.framework.Test suite() {
		return new JUnit4TestAdapter(AllTestClasses.class);
	}
}
