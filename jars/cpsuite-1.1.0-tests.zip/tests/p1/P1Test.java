package tests.p1;

import org.junit.Test;

public class P1Test {

	@Test
	public void test1() {
	}
}
