package tests.p1;

import org.junit.Test;

public class P1NoTest {

	public static class InnerTest {
		@Test
		public void innerTest() {
		}
	}
}