package tests.ju38;

import junit.framework.TestCase;

public class JU38Test extends TestCase {

	public void testOk() {

	}

	public void testFailure() {
		fail("expected");
	}
}
