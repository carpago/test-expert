package tests.ju38;

import junit.framework.TestCase;

public abstract class JU38AbstractTest extends TestCase {

}
