package tests.p2;

public class ConcreteP2Test extends AbstractP2Test {

}
