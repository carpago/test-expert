package org.junit.extensions.cpsuite;

public enum SuiteType {
	TEST_CLASSES, RUN_WITH_CLASSES, JUNIT38_TEST_CLASSES
}